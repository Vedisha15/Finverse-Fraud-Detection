# Upload this project to GitHub

## Option 1 — GitHub Desktop

1. Create a new repository on GitHub named `Finverse-Fraud-Detection`.
2. Open GitHub Desktop.
3. Choose **Add → Add existing repository**.
4. Select this folder.
5. Commit all files with:

```text
Initial Finverse fraud detection portfolio
```

6. Click **Publish repository**.

## Option 2 — Git commands

Open a terminal inside this folder:

```bash
git init
git add .
git commit -m "Initial Finverse fraud detection portfolio"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Do not upload the raw BankSim CSV or generated model pickle unless you specifically need them and have checked their size/licensing.

# Models

The notebook trains an XGBoost fraud classifier and saves it as:

```text
XGB-BankSim.pkl
```

The generated model file is intentionally ignored by Git in `.gitignore`.

For a reproducible repository, retrain the model from the notebook or from the training script after adding the BankSim dataset.

# Finverse — Interview Questions & Short Answers

## Basic Questions

### 1. What is Finverse?

Finverse is a fraud-detection and risk-monitoring project that uses transaction analysis and machine learning to identify suspicious behavior.

### 2. What problem does it solve?

It helps identify potentially fraudulent transaction patterns and supports faster review of suspicious activity.

### 3. Which dataset did you use?

I used the BankSim transaction dataset.

### 4. How many transactions were there?

The notebook contains 594,643 transactions, including 7,200 fraud transactions.

### 5. Which algorithm did you use?

I used the XGBoost Classifier.

### 6. Why XGBoost?

It is suitable for structured/tabular data and can learn complex relationships using boosted decision trees.

### 7. What is fraud detection?

Fraud detection is the process of identifying transactions that may be fraudulent or suspicious.

### 8. What is anomaly detection?

Anomaly detection means identifying observations that differ from normal patterns.

---

## Feature Engineering

### 9. What features did you create?

I created customer and customer–merchant transaction counts over 1-day, 7-day and 30-day windows.

### 10. Why did you create these features?

They capture recent transaction behavior, which can provide useful fraud signals.

### 11. Give an example.

If a customer suddenly makes many transactions in a short time, the transaction frequency can become a useful risk signal.

---

## Machine Learning

### 12. What is XGBoost?

XGBoost is a gradient-boosting algorithm that combines decision trees to build a strong predictive model.

### 13. What is class imbalance?

Class imbalance occurs when one class has many more observations than another. Here, genuine transactions are much more common than fraud.

### 14. How did you handle imbalance?

The notebook calculates the ratio between the majority and minority classes and uses it as a positive-class weight.

### 15. What metric did you use?

I used AUPRC, implemented through `average_precision_score`.

### 16. What was the AUPRC before feature engineering?

0.8331.

### 17. What was the AUPRC after feature engineering?

0.8812.

### 18. What was the improvement?

The AUPRC increased by about 0.0481 points, or 5.77% relative to the baseline.

---

## Dashboard

### 19. What is the purpose of the dashboard?

It provides a simple visual view of transaction volume, fraud rate, categories and transaction amounts.

### 20. Why use a dashboard?

A dashboard makes large amounts of transaction information easier to monitor and understand.

### 21. What is a fraud alert?

It is a notification/flag generated when a transaction is considered potentially suspicious.

### 22. Is the current notebook a real-time streaming system?

The supplied notebook is primarily a batch analysis and ML-training pipeline. A production version can connect the trained model to a live transaction stream and alerting service.

---

## Challenging Questions

### 23. Why is accuracy not enough?

Because fraud is rare. A model can achieve high accuracy while missing many fraud cases.

### 24. What is a false positive?

A genuine transaction incorrectly classified as fraud.

### 25. What is a false negative?

A fraudulent transaction incorrectly classified as genuine.

### 26. Which is dangerous in fraud detection?

False negatives are especially important because actual fraud can be missed.

### 27. What would you improve next?

I would add real-time streaming, threshold optimization, model monitoring, explainability, automated alerts and cloud deployment.

### 28. What was the most important part of the project?

Behavioral feature engineering was especially important because adding recent customer and customer–merchant activity improved AUPRC.

---

## 30-second answer

“Finverse is a fraud-detection project built using BankSim transaction data. I performed exploratory analysis and created behavioral features based on recent customer and customer–merchant transaction counts over 1, 7 and 30 days. I trained an XGBoost classifier and evaluated it using AUPRC because the dataset is highly imbalanced. The AUPRC improved from 0.8331 with standard features to 0.8812 after feature engineering. I also created a monitoring dashboard concept to make the fraud insights easier to review.”
